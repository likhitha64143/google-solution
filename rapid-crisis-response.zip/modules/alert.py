def send_alert(incident):
    print(f"[ALERT] {incident}")
