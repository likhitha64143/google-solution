def detect_incident(incident_type, location):
    severity_map = {"fire": "High", "medical": "Medium", "security": "High"}
    return {"type": incident_type, "location": location, "severity": severity_map.get(incident_type, "Low")}
