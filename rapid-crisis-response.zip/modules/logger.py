def log_incident(incident, staff):
    with open("incident_log.txt", "a") as f:
        f.write(f"{incident} -> {staff}\n")
