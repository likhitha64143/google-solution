def assign_task(incident):
    staff = {"fire": "Fire Team", "medical": "Medical Team", "security": "Security Team"}
    return staff.get(incident["type"], "General Staff")
