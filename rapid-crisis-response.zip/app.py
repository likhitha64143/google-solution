from flask import Flask, render_template, request, redirect, url_for
from modules.detector import detect_incident
from modules.alert import send_alert
from modules.task_assigner import assign_task
from modules.logger import log_incident

app = Flask(__name__)
incidents = []

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/report', methods=['POST'])
def report():
    incident_type = request.form['type']
    location = request.form['location']

    incident = detect_incident(incident_type, location)
    send_alert(incident)
    assigned_staff = assign_task(incident)
    log_incident(incident, assigned_staff)

    incidents.append({**incident, "assigned": assigned_staff})
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html', incidents=incidents)

if __name__ == '__main__':
    app.run(debug=True)
