# Rapid Crisis Response System

AI-driven emergency response system for hospitality.

## Run
pip install -r requirements.txt
python app.py
